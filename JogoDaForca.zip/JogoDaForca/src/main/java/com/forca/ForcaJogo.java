package com.forca;

import java.util.ArrayList;
import java.util.List;

public class ForcaJogo {

    private String palavra;
    private List<Character> letrasCertas;
    private List<Character> letrasErradas;

    public ForcaJogo() {
        this.palavra = "JAVA";
        this.letrasCertas = new ArrayList<>();
        this.letrasErradas = new ArrayList<>();
    }

    public String getPalavra() {
        return palavra;
    }

    public List<Character> getLetrasCertas() {
        return letrasCertas;
    }

    public List<Character> getLetrasErradas() {
        return letrasErradas;
    }

    public boolean tentarLetra(char letra) {
        boolean letraCorreta = palavra.indexOf(letra) >= 0;
        
        if (letraCorreta && !letrasCertas.contains(letra)) {
            letrasCertas.add(letra);
        } else if (!letraCorreta && !letrasErradas.contains(letra)) {
            letrasErradas.add(letra);
        }
        
        return letraCorreta;
    }

    public boolean venceu() {
        for (int i = 0; i < palavra.length(); i++) {
            if (!letrasCertas.contains(palavra.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public boolean perdeu() {
        return letrasErradas.size() >= 6;
    }
}
